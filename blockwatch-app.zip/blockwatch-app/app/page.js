import "./globals.css";
import BlockwatchApp from "./components/BlockwatchApp";

export default function Page() {
  return <BlockwatchApp />;
}
