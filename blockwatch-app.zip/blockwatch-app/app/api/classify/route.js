const TYPE_LABEL = {
  vehicle_theft: "Vehicle theft",
  burglary: "Burglary",
  robbery: "Robbery",
  lost_phone: "Lost/stolen phone",
  suspicious: "Suspicious activity",
  vandalism: "Vandalism",
  other: "Other",
};

// Keyword fallback used if the AI call fails or no API key is configured yet.
function heuristicClassify(description, type) {
  const text = description.toLowerCase();
  let severity = 2;
  if (/gun|weapon|knife|armed|assault|forced|threat/.test(text)) severity = 5;
  else if (/night|dark|multiple|group|broke in|smashed/.test(text)) severity = 4;
  else if (type === "robbery") severity = Math.max(severity, 4);
  else if (type === "vehicle_theft" || type === "burglary") severity = Math.max(severity, 3);
  const tags = [];
  if (/night|dark|2am|3am|late/.test(text)) tags.push("night-time");
  if (/gate|fence|wall/.test(text)) tags.push("perimeter breach");
  if (/camera|cctv/.test(text)) tags.push("on camera");
  return { severity, summary: description.slice(0, 140), tags, source: "heuristic" };
}

export async function POST(req) {
  let body;
  try {
    body = await req.json();
  } catch (e) {
    return Response.json({ error: "Invalid request body" }, { status: 400 });
  }
  const { description, type } = body || {};
  if (!description || typeof description !== "string") {
    return Response.json({ error: "description is required" }, { status: 400 });
  }

  const apiKey = process.env.ANTHROPIC_API_KEY;
  if (!apiKey) {
    // No key configured yet -- fall back gracefully instead of failing the report.
    return Response.json(heuristicClassify(description, type));
  }

  const system = `You are a community safety analyst. Given a short incident report, return ONLY a JSON object, no prose, no markdown fences, matching exactly this shape:
{"severity": <integer 1-5, 5 = most dangerous/violent>, "summary": "<one plain sentence, under 20 words>", "tags": ["<short risk tag>", "..."] }
Base severity on: presence of weapons or violence (5), forced entry / confrontation / multiple offenders (4), theft without confrontation (3), suspicious but unconfirmed activity (2), minor/nuisance (1). Keep tags to at most 4, short lowercase phrases like "night-time", "armed", "vehicle involved", "repeat location".`;

  try {
    const res = await fetch("https://api.anthropic.com/v1/messages", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        "x-api-key": apiKey,
        "anthropic-version": "2023-06-01",
      },
      body: JSON.stringify({
        // Haiku keeps per-report cost low; swap to "claude-sonnet-5" for higher-quality classification.
        model: "claude-haiku-4-5-20251001",
        max_tokens: 300,
        system,
        messages: [
          { role: "user", content: `Incident type: ${TYPE_LABEL[type] || type}\nReport: ${description}` },
        ],
      }),
    });

    if (!res.ok) {
      return Response.json(heuristicClassify(description, type));
    }

    const data = await res.json();
    const text = (data.content || []).map((b) => b.text || "").join("\n");
    const clean = text.replace(/```json|```/g, "").trim();
    const parsed = JSON.parse(clean);
    const severity = Math.min(5, Math.max(1, Math.round(Number(parsed.severity) || 2)));
    return Response.json({
      severity,
      summary: String(parsed.summary || description.slice(0, 140)),
      tags: Array.isArray(parsed.tags) ? parsed.tags.slice(0, 4) : [],
      source: "ai",
    });
  } catch (e) {
    return Response.json(heuristicClassify(description, type));
  }
}
