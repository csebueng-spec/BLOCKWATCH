"use client";

import React, { useState, useEffect, useMemo, useRef } from "react";
import {
  LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip,
  ResponsiveContainer, BarChart, Bar
} from "recharts";
import { supabase } from "../../lib/supabaseClient";

const HALF_LIFE_DAYS = 14;
const CELL_SIZE_DEG = 0.0015;
const RETENTION_DAYS = 120;
const RATE_LIMIT_COUNT = 5;
const RATE_LIMIT_WINDOW_MIN = 60;

const INCIDENT_TYPES = [
  { id: "vehicle_theft", label: "Vehicle theft" },
  { id: "burglary", label: "Burglary" },
  { id: "robbery", label: "Robbery" },
  { id: "lost_phone", label: "Lost/stolen phone" },
  { id: "suspicious", label: "Suspicious activity" },
  { id: "vandalism", label: "Vandalism" },
  { id: "other", label: "Other" },
];
const TYPE_LABEL = Object.fromEntries(INCIDENT_TYPES.map(t => [t.id, t.label]));
const SEVERITY_COLORS = { 1: "#4F9C93", 2: "#6FA97E", 3: "#E8A33D", 4: "#D9722F", 5: "#C1443C" };

function daysSince(iso) { return (Date.now() - new Date(iso).getTime()) / 86400000; }
function decayWeight(iso) { return Math.pow(0.5, daysSince(iso) / HALF_LIFE_DAYS); }
function cellKey(lat, lng) { return `${Math.round(lat / CELL_SIZE_DEG)}:${Math.round(lng / CELL_SIZE_DEG)}`; }
function cellCentroid(key) { const [x, y] = key.split(":").map(Number); return { lat: x * CELL_SIZE_DEG, lng: y * CELL_SIZE_DEG }; }
function formatLatLng(lat, lng) { return `${lat.toFixed(4)}, ${lng.toFixed(4)}`; }
function hexToRgb(hex) { const n = parseInt(hex.slice(1), 16); return { r: (n >> 16) & 255, g: (n >> 8) & 255, b: n & 255 }; }
function lerpColor(a, b, t) {
  const pa = hexToRgb(a), pb = hexToRgb(b);
  return `rgb(${Math.round(pa.r + (pb.r - pa.r) * t)},${Math.round(pa.g + (pb.g - pa.g) * t)},${Math.round(pa.b + (pb.b - pa.b) * t)})`;
}
function riskColor(t) { return t < 0.5 ? lerpColor("#2C5E58", "#C98A2B", t / 0.5) : lerpColor("#C98A2B", "#C1443C", (t - 0.5) / 0.5); }
function relativeTime(iso) {
  const d = daysSince(iso);
  if (d < 1 / 24) return "just now";
  if (d < 1) return `${Math.round(d * 24)}h ago`;
  if (d < 7) return `${Math.round(d)}d ago`;
  return new Date(iso).toLocaleDateString(undefined, { month: "short", day: "numeric" });
}
function computeCellRisk(reports) {
  const cells = {};
  for (const r of reports) {
    const key = cellKey(r.lat, r.lng);
    cells[key] = (cells[key] || 0) + decayWeight(r.created_at) * r.severity;
  }
  return cells;
}
function communityRiskLevel(cellRisk) {
  const values = Object.values(cellRisk);
  if (values.length === 0) return { label: "No data" };
  const total = values.reduce((a, b) => a + b, 0);
  const max = Math.max(...values);
  const score = total * 0.4 + max * 0.6;
  if (score > 18) return { label: "Elevated" };
  if (score > 8) return { label: "Watchful" };
  return { label: "Calm" };
}
function statusColor(label) {
  if (label === "Elevated") return "#C1443C";
  if (label === "Watchful") return "#E8A33D";
  if (label === "Calm") return "#4F9C93";
  return "#8E98A6";
}

export default function BlockwatchApp() {
  const [session, setSession] = useState(undefined); // undefined = loading, null = signed out
  const [authEmail, setAuthEmail] = useState("");
  const [authSent, setAuthSent] = useState(false);
  const [authError, setAuthError] = useState("");

  const [profileName, setProfileName] = useState("");
  const [editingName, setEditingName] = useState(false);
  const [nameInput, setNameInput] = useState("");

  const [center, setCenter] = useState({ lat: -26.2041, lng: 28.0473, label: "Johannesburg, South Africa" });
  const [reports, setReports] = useState([]);
  const [cameras, setCameras] = useState([]);
  const [loaded, setLoaded] = useState(false);

  const [mapMode, setMapMode] = useState("incident");
  const [activeForm, setActiveForm] = useState(null);
  const [pendingLoc, setPendingLoc] = useState(null);
  const [form, setForm] = useState({ type: "vehicle_theft", description: "", street: "" });
  const [cameraForm, setCameraForm] = useState({ street: "", notes: "" });
  const [analyzing, setAnalyzing] = useState(false);
  const [error, setError] = useState("");

  const [leafletReady, setLeafletReady] = useState(false);
  const [showSearch, setShowSearch] = useState(false);
  const [searchQuery, setSearchQuery] = useState("");
  const [searchResults, setSearchResults] = useState([]);
  const [searching, setSearching] = useState(false);

  const mapDivRef = useRef(null);
  const mapObjRef = useRef(null);
  const heatLayerRef = useRef(null);
  const cameraLayerRef = useRef(null);
  const pendingLayerRef = useRef(null);
  const mapModeRef = useRef(mapMode);
  useEffect(() => { mapModeRef.current = mapMode; }, [mapMode]);

  // ---- auth ----
  useEffect(() => {
    supabase.auth.getSession().then(({ data }) => setSession(data.session));
    const { data: listener } = supabase.auth.onAuthStateChange((_event, s) => setSession(s));
    return () => listener.subscription.unsubscribe();
  }, []);

  async function sendMagicLink(e) {
    e.preventDefault();
    setAuthError("");
    const { error } = await supabase.auth.signInWithOtp({
      email: authEmail.trim(),
      options: { emailRedirectTo: typeof window !== "undefined" ? window.location.origin : undefined },
    });
    if (error) setAuthError(error.message);
    else setAuthSent(true);
  }

  async function signOut() { await supabase.auth.signOut(); }

  // ---- profile (display name) ----
  useEffect(() => {
    if (!session) return;
    (async () => {
      const { data } = await supabase.from("profiles").select("display_name").eq("id", session.user.id).maybeSingle();
      if (data && data.display_name) setProfileName(data.display_name);
      else setEditingName(true);
    })();
  }, [session]);

  async function saveProfileName(name) {
    const trimmed = name.trim().slice(0, 40);
    if (!trimmed || !session) return;
    await supabase.from("profiles").upsert({ id: session.user.id, display_name: trimmed });
    setProfileName(trimmed);
    setEditingName(false);
  }

  // ---- leaflet load check ----
  useEffect(() => {
    if (window.L) { setLeafletReady(true); return; }
    const t = setInterval(() => { if (window.L) { setLeafletReady(true); clearInterval(t); } }, 150);
    return () => clearInterval(t);
  }, []);

  // ---- initial data load ----
  useEffect(() => {
    if (!session) return;
    (async () => {
      const { data: settings } = await supabase.from("community_settings").select("*").eq("id", 1).maybeSingle();
      if (settings) setCenter({ lat: settings.center_lat, lng: settings.center_lng, label: settings.center_label });
      else setShowSearch(true);

      const since = new Date(Date.now() - RETENTION_DAYS * 86400000).toISOString();
      const { data: reportRows } = await supabase.from("reports").select("*").gte("created_at", since).order("created_at", { ascending: false });
      setReports(reportRows || []);
      const { data: cameraRows } = await supabase.from("cameras").select("*").order("created_at", { ascending: false });
      setCameras(cameraRows || []);
      setLoaded(true);
    })();
  }, [session]);

  // ---- realtime subscriptions ----
  useEffect(() => {
    if (!session) return;
    const channel = supabase
      .channel("blockwatch-live")
      .on("postgres_changes", { event: "*", schema: "public", table: "reports" }, (payload) => {
        setReports((prev) => {
          if (payload.eventType === "INSERT") return [payload.new, ...prev.filter(r => r.id !== payload.new.id)];
          if (payload.eventType === "DELETE") return prev.filter(r => r.id !== payload.old.id);
          return prev;
        });
      })
      .on("postgres_changes", { event: "*", schema: "public", table: "cameras" }, (payload) => {
        setCameras((prev) => {
          if (payload.eventType === "INSERT") return [payload.new, ...prev.filter(c => c.id !== payload.new.id)];
          if (payload.eventType === "DELETE") return prev.filter(c => c.id !== payload.old.id);
          return prev;
        });
      })
      .subscribe();
    return () => supabase.removeChannel(channel);
  }, [session]);

  async function persistCenter(next) {
    setCenter(next);
    await supabase.from("community_settings").upsert({
      id: 1, center_lat: next.lat, center_lng: next.lng, center_label: next.label, updated_at: new Date().toISOString(),
    });
  }

  function withinRateLimit() {
    const windowMs = RATE_LIMIT_WINDOW_MIN * 60000;
    const recent = reports.filter(r => session && r.reported_by === session.user.id && Date.now() - new Date(r.created_at).getTime() < windowMs).length;
    return recent < RATE_LIMIT_COUNT;
  }

  async function removeReport(id) {
    if (!window.confirm("Remove this report?")) return;
    const { error } = await supabase.from("reports").delete().eq("id", id);
    if (error) setError("Couldn't remove that report — you can only remove reports you created.");
    else setReports(prev => prev.filter(r => r.id !== id));
  }
  async function removeCamera(id) {
    if (!window.confirm("Remove this camera listing?")) return;
    const { error } = await supabase.from("cameras").delete().eq("id", id);
    if (error) setError("Couldn't remove that camera — you can only remove ones you registered.");
    else setCameras(prev => prev.filter(c => c.id !== id));
  }

  // ---- derived ----
  const cellRisk = useMemo(() => computeCellRisk(reports), [reports]);
  const maxRisk = useMemo(() => Math.max(1, ...Object.values(cellRisk)), [cellRisk]);
  const riskLevel = useMemo(() => communityRiskLevel(cellRisk), [cellRisk]);

  const alertZones = useMemo(() => {
    return Object.entries(cellRisk)
      .filter(([, v]) => v > maxRisk * 0.55 && v > 4)
      .map(([key, v]) => {
        const centroid = cellCentroid(key);
        const zoneReports = reports.filter(r => cellKey(r.lat, r.lng) === key);
        const latest = zoneReports.sort((a, b) => new Date(b.created_at) - new Date(a.created_at))[0];
        return { key, centroid, score: v, count: zoneReports.length, latest };
      })
      .sort((a, b) => b.score - a.score).slice(0, 5);
  }, [cellRisk, maxRisk, reports]);

  const weeklyTrend = useMemo(() => {
    const weeks = {};
    const now = Date.now();
    for (let i = 7; i >= 0; i--) {
      const label = new Date(now - i * 7 * 86400000).toLocaleDateString(undefined, { month: "short", day: "numeric" });
      weeks[label] = { week: label, count: 0 };
    }
    const labels = Object.keys(weeks);
    reports.forEach(r => {
      const idx = Math.max(0, Math.min(7, 7 - Math.floor(daysSince(r.created_at) / 7)));
      const label = labels[idx];
      if (weeks[label]) weeks[label].count += 1;
    });
    return Object.values(weeks);
  }, [reports]);

  const typeBreakdown = useMemo(() =>
    INCIDENT_TYPES.map(t => ({ type: t.label, count: reports.filter(r => r.type === t.id).length })).filter(t => t.count > 0)
  , [reports]);

  // ---- map init ----
  useEffect(() => {
    if (!leafletReady || !loaded || !mapDivRef.current || mapObjRef.current) return;
    const L = window.L;
    const map = L.map(mapDivRef.current, { zoomControl: true }).setView([center.lat, center.lng], 15);
    L.tileLayer("https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png", {
      attribution: '&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors',
      maxZoom: 19,
    }).addTo(map);
    heatLayerRef.current = L.layerGroup().addTo(map);
    cameraLayerRef.current = L.layerGroup().addTo(map);
    pendingLayerRef.current = L.layerGroup().addTo(map);
    map.on("click", (e) => {
      setPendingLoc({ lat: e.latlng.lat, lng: e.latlng.lng });
      setActiveForm(mapModeRef.current);
      setError("");
    });
    mapObjRef.current = map;
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [leafletReady, loaded]);

  useEffect(() => { if (mapObjRef.current) mapObjRef.current.setView([center.lat, center.lng], 15); }, [center]);

  useEffect(() => {
    if (!mapObjRef.current || !heatLayerRef.current) return;
    const L = window.L;
    heatLayerRef.current.clearLayers();
    Object.entries(cellRisk).forEach(([key, v]) => {
      const { lat, lng } = cellCentroid(key);
      const t = Math.min(1, v / maxRisk);
      L.circle([lat, lng], { radius: 55, color: riskColor(t), fillColor: riskColor(t), fillOpacity: 0.35, weight: 1 }).addTo(heatLayerRef.current);
    });
  }, [cellRisk, maxRisk, leafletReady]);

  useEffect(() => {
    if (!mapObjRef.current || !cameraLayerRef.current) return;
    const L = window.L;
    cameraLayerRef.current.clearLayers();
    cameras.forEach(c => {
      L.circleMarker([c.lat, c.lng], { radius: 6, color: "#151B23", weight: 1.5, fillColor: "#8FB8E8", fillOpacity: 1 })
        .bindPopup(`<b>${c.street || "Camera"}</b>${c.notes ? `<br/>${c.notes}` : ""}`)
        .addTo(cameraLayerRef.current);
    });
  }, [cameras, leafletReady]);

  useEffect(() => {
    if (!mapObjRef.current || !pendingLayerRef.current) return;
    const L = window.L;
    pendingLayerRef.current.clearLayers();
    if (pendingLoc) {
      L.circleMarker([pendingLoc.lat, pendingLoc.lng], { radius: 8, color: "#E9E4DA", weight: 2, fillColor: "#E8A33D", fillOpacity: 1 }).addTo(pendingLayerRef.current);
    }
  }, [pendingLoc, leafletReady]);

  async function runSearch(e) {
    e.preventDefault();
    if (!searchQuery.trim()) return;
    setSearching(true);
    setSearchResults([]);
    try {
      const res = await fetch(`https://nominatim.openstreetmap.org/search?format=json&limit=5&q=${encodeURIComponent(searchQuery)}`);
      setSearchResults(await res.json());
    } catch (e) { setError("Location search failed — check your connection and try again."); }
    finally { setSearching(false); }
  }
  function pickSearchResult(r) {
    persistCenter({ lat: parseFloat(r.lat), lng: parseFloat(r.lon), label: r.display_name });
    setSearchResults([]); setSearchQuery(""); setShowSearch(false);
  }
  function useMyLocation() {
    if (!navigator.geolocation) { setError("Your browser doesn't support location lookup — search your address instead."); return; }
    navigator.geolocation.getCurrentPosition(
      (pos) => { persistCenter({ lat: pos.coords.latitude, lng: pos.coords.longitude, label: "My location" }); setShowSearch(false); },
      () => setError("Couldn't get your location — search your address instead.")
    );
  }

  async function submitReport(e) {
    e.preventDefault();
    if (!pendingLoc) { setError("Tap the map first to mark where this happened."); return; }
    if (!form.description.trim()) { setError("Add a short description of what happened."); return; }
    if (!withinRateLimit()) { setError(`To limit spam, only ${RATE_LIMIT_COUNT} reports per ${RATE_LIMIT_WINDOW_MIN} minutes. Try again shortly.`); return; }

    setAnalyzing(true);
    setError("");
    let classification = { severity: 2, summary: form.description.slice(0, 140), tags: [] };
    try {
      const res = await fetch("/api/classify", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ description: form.description, type: form.type }),
      });
      classification = await res.json();
    } catch (e) { /* keep default classification */ }
    setAnalyzing(false);

    const { error } = await supabase.from("reports").insert({
      type: form.type,
      description: form.description.trim(),
      street: form.street.trim(),
      lat: pendingLoc.lat,
      lng: pendingLoc.lng,
      severity: classification.severity,
      summary: classification.summary,
      tags: classification.tags,
      reported_by: session.user.id,
      reported_by_name: profileName || "Anonymous",
    });
    if (error) { setError("Couldn't save the report — please try again."); return; }
    setForm({ type: "vehicle_theft", description: "", street: "" });
    setPendingLoc(null); setActiveForm(null);
  }

  async function submitCamera(e) {
    e.preventDefault();
    if (!pendingLoc) { setError("Tap the map first to mark where the camera points."); return; }
    const { error } = await supabase.from("cameras").insert({
      street: cameraForm.street.trim(),
      notes: cameraForm.notes.trim(),
      lat: pendingLoc.lat,
      lng: pendingLoc.lng,
      registered_by: session.user.id,
      registered_by_name: profileName || "Anonymous",
    });
    if (error) { setError("Couldn't save the camera — please try again."); return; }
    setCameraForm({ street: "", notes: "" });
    setPendingLoc(null); setActiveForm(null); setError("");
  }

  // ---- render: loading ----
  if (session === undefined) {
    return <div style={{ ...styles.app, display: "flex", alignItems: "center", justifyContent: "center", minHeight: "100vh" }}>Loading…</div>;
  }

  // ---- render: signed out ----
  if (!session) {
    return (
      <div style={{ ...styles.app, minHeight: "100vh", display: "flex", alignItems: "center", justifyContent: "center" }}>
        <div style={{ ...styles.panel, maxWidth: 380, width: "100%" }}>
          <div style={styles.eyebrow}>Neighborhood watch log</div>
          <h1 style={{ ...styles.h1, fontSize: 32 }}>Blockwatch</h1>
          <p style={{ fontSize: 13.5, color: "#B8C0CB", marginTop: 8 }}>
            Sign in with your email — no password needed. We'll send you a one-time link.
          </p>
          {authSent ? (
            <p style={{ fontSize: 13.5, color: "#4F9C93" }}>Check your inbox for a sign-in link.</p>
          ) : (
            <form onSubmit={sendMagicLink} style={styles.form}>
              <input
                style={styles.input}
                type="email"
                required
                placeholder="you@example.com"
                value={authEmail}
                onChange={e => setAuthEmail(e.target.value)}
              />
              <button type="submit" style={{ ...styles.primaryBtn, marginTop: 10 }}>Send sign-in link</button>
            </form>
          )}
          {authError && <div style={styles.error}>{authError}</div>}
        </div>
      </div>
    );
  }

  // ---- render: signed in ----
  return (
    <div style={styles.app}>
      <header style={styles.header}>
        <div>
          <div style={styles.eyebrow}>Neighborhood watch log</div>
          <h1 style={styles.h1}>Blockwatch</h1>
        </div>
        <div style={{ display: "flex", alignItems: "center", gap: 12 }}>
          <div style={styles.statusPill(riskLevel.label)}>
            <span style={styles.statusDot(riskLevel.label)} />
            {riskLevel.label}
          </div>
          <button style={styles.ghostBtn} onClick={signOut}>Sign out</button>
        </div>
      </header>

      {editingName ? (
        <div style={styles.namePanel}>
          <div>
            <div style={styles.nameTitle}>What should neighbors see you as?</div>
            <div style={styles.hint}>Shown next to anything you post. You're signed in with {session.user.email}.</div>
          </div>
          <form style={{ display: "flex", gap: 8 }} onSubmit={(e) => { e.preventDefault(); saveProfileName(nameInput); }}>
            <input style={styles.input} placeholder="e.g. Sarah, 12 Oak St" value={nameInput} onChange={e => setNameInput(e.target.value)} autoFocus />
            <button type="submit" style={styles.primaryBtn}>Save</button>
          </form>
        </div>
      ) : (
        <div style={styles.nameRow}>
          Posting as <strong>{profileName}</strong>
          <button style={styles.linkBtn} onClick={() => { setNameInput(profileName); setEditingName(true); }}>change</button>
        </div>
      )}

      <div className="cw-layout">
        <div style={styles.col}>
          <div style={styles.panel}>
            <div style={styles.panelHeadRow}>
              <h2 style={styles.h2}>{center.label || "Community map"}</h2>
              <div style={styles.segmentGroup}>
                <button style={styles.segmentBtn(mapMode === "incident")} onClick={() => { setMapMode("incident"); if (pendingLoc) setActiveForm("incident"); }}>Log incident</button>
                <button style={styles.segmentBtn(mapMode === "camera")} onClick={() => { setMapMode("camera"); if (pendingLoc) setActiveForm("camera"); }}>Register camera</button>
              </div>
            </div>
            <div style={styles.panelHeadRow}>
              <span style={styles.hint}>{mapMode === "camera" ? "tap the map to mark where a camera covers" : "tap the map to log a report"}</span>
              <button style={styles.linkBtn} onClick={() => setShowSearch(s => !s)}>Change location</button>
            </div>

            {showSearch && (
              <form onSubmit={runSearch} style={{ ...styles.form, marginBottom: 10 }}>
                <div style={{ display: "flex", gap: 6 }}>
                  <input style={{ ...styles.input, flex: 1 }} placeholder="Search your street or suburb" value={searchQuery} onChange={e => setSearchQuery(e.target.value)} />
                  <button type="submit" style={styles.primaryBtn} disabled={searching}>{searching ? "…" : "Search"}</button>
                  <button type="button" style={styles.ghostBtn} onClick={useMyLocation}>Use my location</button>
                </div>
                {searchResults.length > 0 && (
                  <ul style={styles.searchList}>
                    {searchResults.map((r, i) => (
                      <li key={i} className="cw-searchresult" style={styles.searchItem} onClick={() => pickSearchResult(r)}>{r.display_name}</li>
                    ))}
                  </ul>
                )}
                <div style={styles.hint}>Powered by OpenStreetMap's Nominatim search.</div>
              </form>
            )}

            <div ref={mapDivRef} className="cw-map" />

            <div style={styles.legendRow}>
              <span style={styles.legendLabel}>Lower risk</span>
              <div style={styles.legendBar} />
              <span style={styles.legendLabel}>Higher risk</span>
            </div>
            <div style={styles.legendRow}>
              <span style={{ ...styles.legendDot, background: "#8FB8E8" }} />
              <span style={styles.legendLabel}>Registered camera coverage</span>
            </div>
          </div>

          <div style={styles.panel}>
            <h2 style={styles.h2}>Active alert zones</h2>
            {alertZones.length === 0 ? (
              <p style={styles.empty}>No zone has crossed the alert threshold yet.</p>
            ) : (
              <ul style={styles.alertList}>
                {alertZones.map(z => (
                  <li key={z.key} style={styles.alertItem}>
                    <div style={styles.alertDot} />
                    <div style={{ flex: 1 }}>
                      <div style={styles.alertTitle}>{z.latest && z.latest.street ? z.latest.street : `Near ${formatLatLng(z.centroid.lat, z.centroid.lng)}`} · {z.count} report{z.count > 1 ? "s" : ""}</div>
                      <div style={styles.alertMeta}>{z.latest ? `Most recent: ${TYPE_LABEL[z.latest.type]}, ${relativeTime(z.latest.created_at)}` : ""}</div>
                    </div>
                    <div style={styles.alertScore}>{z.score.toFixed(1)}</div>
                  </li>
                ))}
              </ul>
            )}
          </div>
        </div>

        <div style={styles.col}>
          <div style={styles.panel}>
            <div style={styles.panelHeadRow}>
              <h2 style={styles.h2}>Report an incident</h2>
              {activeForm !== "incident" && (
                <button style={styles.primaryBtn} onClick={() => { setMapMode("incident"); setActiveForm("incident"); if (!pendingLoc) setError("Tap the map to mark the location."); }}>New report</button>
              )}
            </div>
            {activeForm === "incident" && (
              <form onSubmit={submitReport} style={styles.form}>
                <label style={styles.label}>Type</label>
                <select style={styles.input} value={form.type} onChange={e => setForm({ ...form, type: e.target.value })}>
                  {INCIDENT_TYPES.map(t => <option key={t.id} value={t.id}>{t.label}</option>)}
                </select>
                <label style={styles.label}>Street / landmark (optional)</label>
                <input style={styles.input} placeholder="e.g. 4th Ave near the park" value={form.street} onChange={e => setForm({ ...form, street: e.target.value })} />
                <label style={styles.label}>What happened</label>
                <textarea style={{ ...styles.input, minHeight: 84, resize: "vertical" }} placeholder="Briefly describe what you saw or experienced." value={form.description} onChange={e => setForm({ ...form, description: e.target.value })} />
                <div style={styles.locHint}>{pendingLoc ? `Location set: ${formatLatLng(pendingLoc.lat, pendingLoc.lng)}` : "Tap the map to set the location."}</div>
                {error && <div style={styles.error}>{error}</div>}
                <div style={styles.formActions}>
                  <button type="button" style={styles.ghostBtn} onClick={() => { setActiveForm(null); setPendingLoc(null); setError(""); }}>Cancel</button>
                  <button type="submit" style={styles.primaryBtn} disabled={analyzing}>{analyzing ? "Analyzing…" : "Submit report"}</button>
                </div>
              </form>
            )}
          </div>

          <div style={styles.panel}>
            <div style={styles.panelHeadRow}>
              <h2 style={styles.h2}>Camera registry</h2>
              {activeForm !== "camera" && (
                <button style={styles.primaryBtn} onClick={() => { setMapMode("camera"); setActiveForm("camera"); if (!pendingLoc) setError("Tap the map to mark where the camera points."); }}>Register camera</button>
              )}
            </div>
            <p style={styles.hint}>No footage is uploaded or stored — this tells neighbors where a camera exists.</p>
            {activeForm === "camera" && (
              <form onSubmit={submitCamera} style={styles.form}>
                <label style={styles.label}>Street / landmark (optional)</label>
                <input style={styles.input} placeholder="e.g. 4th Ave near the park" value={cameraForm.street} onChange={e => setCameraForm({ ...cameraForm, street: e.target.value })} />
                <label style={styles.label}>What it covers (optional)</label>
                <input style={styles.input} placeholder="e.g. faces the driveway and street" value={cameraForm.notes} onChange={e => setCameraForm({ ...cameraForm, notes: e.target.value })} />
                <div style={styles.locHint}>{pendingLoc ? `Location set: ${formatLatLng(pendingLoc.lat, pendingLoc.lng)}` : "Tap the map to set the location."}</div>
                {error && <div style={styles.error}>{error}</div>}
                <div style={styles.formActions}>
                  <button type="button" style={styles.ghostBtn} onClick={() => { setActiveForm(null); setPendingLoc(null); setError(""); }}>Cancel</button>
                  <button type="submit" style={styles.primaryBtn}>Save camera</button>
                </div>
              </form>
            )}
            {cameras.length > 0 && (
              <ul style={{ ...styles.logList, maxHeight: 180, marginTop: 12 }} className="cw-scroll">
                {cameras.map(c => (
                  <li key={c.id} style={styles.logItem}>
                    <div style={{ ...styles.sevBadge(1), background: "#8FB8E8" }}>◎</div>
                    <div style={{ flex: 1 }}>
                      <div style={styles.logTitle}>{c.street || formatLatLng(c.lat, c.lng)}</div>
                      {c.notes && <div style={styles.logDesc}>{c.notes}</div>}
                      <div style={styles.logMeta}>by {c.registered_by_name || "Anonymous"}</div>
                    </div>
                    <button style={styles.removeBtn} title="Remove" onClick={() => removeCamera(c.id)}>×</button>
                  </li>
                ))}
              </ul>
            )}
          </div>

          <div style={styles.panel}>
            <h2 style={styles.h2}>Weekly trend</h2>
            <div style={{ width: "100%", height: 180 }}>
              <ResponsiveContainer>
                <LineChart data={weeklyTrend} margin={{ top: 8, right: 12, left: -20, bottom: 0 }}>
                  <CartesianGrid stroke="#2A3340" strokeDasharray="3 3" />
                  <XAxis dataKey="week" tick={{ fill: "#9AA5B1", fontSize: 11 }} axisLine={{ stroke: "#2A3340" }} tickLine={false} />
                  <YAxis tick={{ fill: "#9AA5B1", fontSize: 11 }} axisLine={{ stroke: "#2A3340" }} tickLine={false} allowDecimals={false} />
                  <Tooltip contentStyle={{ background: "#1B232D", border: "1px solid #2A3340", borderRadius: 6, color: "#E9E4DA" }} />
                  <Line type="monotone" dataKey="count" stroke="#E8A33D" strokeWidth={2} dot={{ r: 3, fill: "#E8A33D" }} name="Reports" />
                </LineChart>
              </ResponsiveContainer>
            </div>
          </div>

          <div style={styles.panel}>
            <h2 style={styles.h2}>By type</h2>
            {typeBreakdown.length === 0 ? <p style={styles.empty}>Nothing logged yet.</p> : (
              <div style={{ width: "100%", height: 180 }}>
                <ResponsiveContainer>
                  <BarChart data={typeBreakdown} layout="vertical" margin={{ top: 4, right: 16, left: 8, bottom: 0 }}>
                    <CartesianGrid stroke="#2A3340" strokeDasharray="3 3" horizontal={false} />
                    <XAxis type="number" tick={{ fill: "#9AA5B1", fontSize: 11 }} axisLine={{ stroke: "#2A3340" }} tickLine={false} allowDecimals={false} />
                    <YAxis dataKey="type" type="category" tick={{ fill: "#E9E4DA", fontSize: 12 }} axisLine={false} tickLine={false} width={110} />
                    <Tooltip contentStyle={{ background: "#1B232D", border: "1px solid #2A3340", borderRadius: 6, color: "#E9E4DA" }} />
                    <Bar dataKey="count" fill="#4F9C93" radius={[0, 3, 3, 0]} />
                  </BarChart>
                </ResponsiveContainer>
              </div>
            )}
          </div>

          <div style={styles.panel}>
            <h2 style={styles.h2}>Recent reports</h2>
            {reports.length === 0 ? <p style={styles.empty}>{loaded ? "No reports yet — add the first one above." : "Loading…"}</p> : (
              <ul style={styles.logList} className="cw-scroll">
                {reports.slice(0, 12).map(r => (
                  <li key={r.id} style={styles.logItem}>
                    <div style={styles.sevBadge(r.severity)}>{r.severity}</div>
                    <div style={{ flex: 1 }}>
                      <div style={styles.logTitle}>{TYPE_LABEL[r.type]}{r.street ? ` · ${r.street}` : ""}</div>
                      <div style={styles.logDesc}>{r.summary || r.description}</div>
                      <div style={styles.logMeta}>{relativeTime(r.created_at)} · {formatLatLng(r.lat, r.lng)} · {r.reported_by_name || "Anonymous"}{r.tags && r.tags.length > 0 ? ` · ${r.tags.join(", ")}` : ""}</div>
                    </div>
                    <button style={styles.removeBtn} title="Remove" onClick={() => removeReport(r.id)}>×</button>
                  </li>
                ))}
              </ul>
            )}
          </div>
        </div>
      </div>

      <footer style={styles.footer}>
        Reports are kept for {RETENTION_DAYS} days. Severity is an automated estimate to help spot patterns — always contact local authorities for emergencies. Map data © OpenStreetMap contributors.
      </footer>
    </div>
  );
}

const styles = {
  app: { fontFamily: "'Inter', system-ui, sans-serif", background: "#12181F", color: "#E9E4DA", minHeight: "100%", padding: "20px 16px 40px" },
  header: { display: "flex", justifyContent: "space-between", alignItems: "flex-end", marginBottom: 20, flexWrap: "wrap", gap: 12 },
  eyebrow: { fontSize: 12, color: "#8E98A6", letterSpacing: "0.02em" },
  h1: { fontFamily: "'Barlow Condensed', sans-serif", fontWeight: 700, fontSize: 40, margin: "2px 0 0", letterSpacing: "0.01em" },
  h2: { fontFamily: "'Barlow Condensed', sans-serif", fontWeight: 600, fontSize: 20, margin: 0 },
  statusPill: (label) => ({ display: "flex", alignItems: "center", gap: 8, padding: "8px 14px", borderRadius: 20, background: "#1B232D", border: `1px solid ${statusColor(label)}55`, fontSize: 14, fontWeight: 500 }),
  statusDot: (label) => ({ width: 8, height: 8, borderRadius: "50%", background: statusColor(label), boxShadow: `0 0 8px ${statusColor(label)}` }),
  col: { display: "flex", flexDirection: "column", gap: 16, minWidth: 0 },
  panel: { background: "#1B232D", border: "1px solid #262F3B", borderRadius: 10, padding: 16 },
  panelHeadRow: { display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 10, gap: 8, flexWrap: "wrap" },
  hint: { fontSize: 12, color: "#8E98A6" },
  linkBtn: { background: "transparent", border: "none", color: "#E8A33D", fontSize: 12.5, cursor: "pointer", padding: 0 },
  legendRow: { display: "flex", alignItems: "center", gap: 8, marginTop: 10 },
  legendLabel: { fontSize: 11, color: "#8E98A6" },
  legendDot: { width: 8, height: 8, borderRadius: "50%", display: "inline-block" },
  legendBar: { flex: 1, height: 6, borderRadius: 3, background: "linear-gradient(90deg, #2C5E58, #C98A2B, #C1443C)" },
  segmentGroup: { display: "flex", gap: 4, background: "#151B23", borderRadius: 7, padding: 3 },
  segmentBtn: (active) => ({ border: "none", borderRadius: 5, padding: "6px 10px", fontSize: 12.5, cursor: "pointer", background: active ? "#E8A33D" : "transparent", color: active ? "#151B23" : "#8E98A6", fontWeight: active ? 600 : 500 }),
  empty: { fontSize: 13, color: "#8E98A6", lineHeight: 1.5, margin: 0 },
  alertList: { listStyle: "none", margin: 0, padding: 0, display: "flex", flexDirection: "column", gap: 10 },
  alertItem: { display: "flex", alignItems: "center", gap: 10, padding: "8px 0", borderBottom: "1px solid #232C38" },
  alertDot: { width: 8, height: 8, borderRadius: "50%", background: "#C1443C", flexShrink: 0 },
  alertTitle: { fontSize: 13.5, fontWeight: 500 },
  alertMeta: { fontSize: 12, color: "#8E98A6", marginTop: 2 },
  alertScore: { fontSize: 13, color: "#C1443C", fontWeight: 600 },
  form: { display: "flex", flexDirection: "column", gap: 4 },
  label: { fontSize: 12, color: "#8E98A6", marginTop: 8, marginBottom: 2 },
  input: { background: "#151B23", border: "1px solid #2A3340", borderRadius: 6, padding: "9px 10px", color: "#E9E4DA", fontSize: 14, outline: "none", width: "100%" },
  locHint: { fontSize: 12, color: "#C98A2B", marginTop: 10 },
  error: { fontSize: 12.5, color: "#E38B84", marginTop: 8 },
  formActions: { display: "flex", justifyContent: "flex-end", gap: 8, marginTop: 14 },
  primaryBtn: { background: "#E8A33D", color: "#151B23", border: "none", borderRadius: 6, padding: "9px 16px", fontSize: 13.5, fontWeight: 600, cursor: "pointer" },
  ghostBtn: { background: "transparent", color: "#8E98A6", border: "1px solid #2A3340", borderRadius: 6, padding: "9px 16px", fontSize: 13.5, cursor: "pointer" },
  searchList: { listStyle: "none", margin: "6px 0 0", padding: 0, background: "#151B23", border: "1px solid #2A3340", borderRadius: 6, overflow: "hidden" },
  searchItem: { padding: "8px 10px", fontSize: 12.5, borderBottom: "1px solid #232C38" },
  logList: { listStyle: "none", margin: 0, padding: 0, display: "flex", flexDirection: "column", gap: 12, maxHeight: 340, overflowY: "auto" },
  logItem: { display: "flex", gap: 10, alignItems: "flex-start" },
  removeBtn: { background: "transparent", border: "none", color: "#5F6975", fontSize: 18, lineHeight: 1, cursor: "pointer", padding: "0 2px", flexShrink: 0 },
  sevBadge: (sev) => ({ width: 24, height: 24, borderRadius: 6, flexShrink: 0, background: SEVERITY_COLORS[sev] || "#4F9C93", color: "#151B23", fontWeight: 700, fontSize: 12, display: "flex", alignItems: "center", justifyContent: "center" }),
  logTitle: { fontSize: 13.5, fontWeight: 500 },
  logDesc: { fontSize: 12.5, color: "#B8C0CB", marginTop: 2, lineHeight: 1.4 },
  logMeta: { fontSize: 11.5, color: "#7C8794", marginTop: 3 },
  footer: { marginTop: 24, fontSize: 11.5, color: "#5F6975", textAlign: "center", lineHeight: 1.5 },
  namePanel: { display: "flex", justifyContent: "space-between", alignItems: "center", gap: 16, flexWrap: "wrap", background: "#1B232D", border: "1px solid #2A3340", borderRadius: 10, padding: 14, marginBottom: 16 },
  nameTitle: { fontSize: 14, fontWeight: 600, marginBottom: 3 },
  nameRow: { fontSize: 12.5, color: "#8E98A6", marginBottom: 16, display: "flex", gap: 8, alignItems: "center" },
};
