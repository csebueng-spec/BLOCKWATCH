# Blockwatch — deployment guide

This is a real, standalone web app: your community's shared incident map, with genuine
email-based sign-in (no passwords to manage) and a real database. Follow these steps in
order — none of them require coding.

## 1. Create your database (Supabase) — 5 min

1. Go to https://supabase.com, sign up free, and create a new project.
2. Once it's ready, open **SQL Editor** (left sidebar) → **New query**.
3. Open `supabase/schema.sql` from this folder, copy all of it, paste it into the query editor, and click **Run**.
4. Go to **Settings → API**. Copy the **Project URL** and the **anon public** key — you'll need both in step 3.
5. Go to **Authentication → Providers** and confirm **Email** is enabled (it is by default). You do not need to set up a password provider — magic links only.

## 2. Get an Anthropic API key — 2 min

1. Go to https://console.anthropic.com, sign in, and create an API key under **API Keys**.
2. This key is billed per use — for a small pilot (a few dozen reports), the cost is a few cents. You can skip this step for now; the app will still work using a simple keyword-based severity estimate instead of AI, and you can add the key later.

## 3. Configure the project

1. Unzip this project on your computer.
2. Copy `.env.local.example` to a new file named `.env.local`.
3. Fill in the three values: your Supabase Project URL, your Supabase anon key, and (optionally) your Anthropic API key.

## 4. Test it locally (optional but recommended)

Requires [Node.js](https://nodejs.org) installed (the free LTS version).

```
npm install
npm run dev
```

Open http://localhost:3000 — you should see the sign-in screen. Try signing in with your own email.

## 5. Deploy it for real (Vercel) — 5 min

1. Install the Vercel CLI: `npm install -g vercel`
2. From this project's folder, run: `vercel`
3. Follow the prompts (create a free Vercel account if you don't have one; accept the defaults).
4. Once it deploys, run `vercel --prod` to get your real production URL.
5. In the Vercel dashboard for this project, go to **Settings → Environment Variables** and add the same three values from your `.env.local` file. Then redeploy (`vercel --prod` again) so the live site picks them up.

## 6. Connect Supabase to your live URL

1. Back in Supabase, go to **Authentication → URL Configuration**.
2. Set **Site URL** to your Vercel production URL (e.g. `https://blockwatch-yourname.vercel.app`).
3. Add the same URL under **Redirect URLs**.

This step matters — without it, the magic-link sign-in emails will redirect people to the wrong place.

## 7. Invite your testers

Just share the URL. Each person enters their email, gets a one-time sign-in link, and picks
a display name the first time. That's the whole "login" flow — genuine per-person accounts,
with no passwords for you to manage or reset.

## What's already handled

- **Real accounts** — Supabase Auth, email magic links
- **Row-level security** — every reader/writer must be signed in; people can only delete
  reports or cameras they created themselves (enforced by the database, not just the UI)
- **Live updates** — when one tester posts a report, everyone else's map updates automatically
- **AI severity scoring** — runs server-side in `app/api/classify/route.js`, so your Anthropic
  key never reaches the browser; falls back to a keyword-based estimate if the AI call fails
  or no key is set

## Known gaps to close before a wider launch

- **Automatic 120-day deletion** isn't wired up yet — right now old reports are just hidden
  from the query, not actually deleted. A Supabase scheduled Edge Function or `pg_cron` job
  can handle real deletion; ask me to build that when you're ready.
- **Rate limiting** (5 reports/hour) is enforced client-side only, which a motivated bad actor
  could bypass. Fine for a small trusted pilot; worth moving server-side before a public launch.
- No content moderation queue yet — anyone signed in can post anything.
