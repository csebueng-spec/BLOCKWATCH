-- Run this once in your Supabase project's SQL editor (Database -> SQL Editor -> New query).

create extension if not exists "pgcrypto";

-- one row per signed-in member, for their display name
create table if not exists profiles (
  id uuid references auth.users on delete cascade primary key,
  display_name text,
  created_at timestamptz default now()
);

-- single row holding where the community map is centered
create table if not exists community_settings (
  id int primary key default 1,
  center_lat double precision not null default -26.2041,
  center_lng double precision not null default 28.0473,
  center_label text default 'Johannesburg, South Africa',
  updated_at timestamptz default now()
);
insert into community_settings (id) values (1) on conflict (id) do nothing;

create table if not exists reports (
  id uuid primary key default gen_random_uuid(),
  type text not null,
  description text not null,
  street text,
  lat double precision not null,
  lng double precision not null,
  severity int not null default 2,
  summary text,
  tags text[] default '{}',
  reported_by uuid references auth.users(id) on delete set null,
  reported_by_name text,
  created_at timestamptz default now()
);

create table if not exists cameras (
  id uuid primary key default gen_random_uuid(),
  street text,
  notes text,
  lat double precision not null,
  lng double precision not null,
  registered_by uuid references auth.users(id) on delete set null,
  registered_by_name text,
  created_at timestamptz default now()
);

-- Row Level Security: only signed-in members can read or write, and only
-- the person who created a report/camera can delete it.
alter table profiles enable row level security;
alter table community_settings enable row level security;
alter table reports enable row level security;
alter table cameras enable row level security;

create policy "profiles viewable by signed-in members" on profiles
  for select using (auth.role() = 'authenticated');
create policy "users manage own profile" on profiles
  for insert with check (auth.uid() = id);
create policy "users update own profile" on profiles
  for update using (auth.uid() = id);

create policy "settings viewable by signed-in members" on community_settings
  for select using (auth.role() = 'authenticated');
create policy "settings updatable by signed-in members" on community_settings
  for update using (auth.role() = 'authenticated');

create policy "reports viewable by signed-in members" on reports
  for select using (auth.role() = 'authenticated');
create policy "reports insertable by signed-in members" on reports
  for insert with check (auth.role() = 'authenticated' and auth.uid() = reported_by);
create policy "reports deletable by their author" on reports
  for delete using (auth.uid() = reported_by);

create policy "cameras viewable by signed-in members" on cameras
  for select using (auth.role() = 'authenticated');
create policy "cameras insertable by signed-in members" on cameras
  for insert with check (auth.role() = 'authenticated' and auth.uid() = registered_by);
create policy "cameras deletable by their author" on cameras
  for delete using (auth.uid() = registered_by);

-- Realtime: lets everyone's map update live when someone else posts.
alter publication supabase_realtime add table reports;
alter publication supabase_realtime add table cameras;
